package scala_tutorial3

object Q5 {
  def main(args : Array[String]):Unit = {
    println(Total_run_time())
  }
  def Total_run_time() = {2*8+3*7+2*8}
}
