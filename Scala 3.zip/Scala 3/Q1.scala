package scala_tutorial3

object Q1 {
  def main(args: Array[String]): Unit = {
    println(Area_of_disk(5))
  }
  def Area_of_disk(r:Double):Double = { scala.math.Pi*r*r}
  }

