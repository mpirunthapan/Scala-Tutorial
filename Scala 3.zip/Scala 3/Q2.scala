package scala_tutorial3

object Q2 {
  def main(args: Array[String]): Unit ={
    println(Temp_to_fahrenheit(35))
  }
  def Temp_to_fahrenheit(c : Double) : Double = { c*1.8000+32.00}
}
