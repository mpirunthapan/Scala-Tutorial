package Tutorial_03

object Q1_2_3 {
  def main(args: Array[String]) = {

    /* Question 1 and Question 2 */

    var i: Int = 2
    var j: Int = 2
    var k: Int = 2
    var m: Int = 5
    var n: Int = 5
    var c: Char = 'X'
    var f: Double = 12.0
    var g: Double = 4.0

    /* End of Question 1 and Question 2 */

    /* Question 3 */

    println("k + 12 * m = " + (k + 12 * m))
    println("m / j = " + (m / j))
    println("f + 10 * 5 + g = " + (f + 10 * 5 + g))
    i += 1
    println("i * n = " + (i * n))

    /* End of Question 3 */

  }
}
